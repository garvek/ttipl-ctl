# ttipl-ctl
TTI USB Control app for PL managed power supply

tested with PL303-P. You can get the product on farnell:
https://fr.farnell.com/aim-tti-instruments/pl303/alimentation-1-voie-30v-3a-ajustable/dp/1510521

official documentation:
https://www.aimtti.com/product-category/dc-power-supplies/aim-plseries 
